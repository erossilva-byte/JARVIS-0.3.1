# J.A.R.V.I.S. Nova 1.39.0

**Raciocínio em etapas, personalidade adaptativa e verificação de respostas.**

## Arquivos

- `jarvis-nova-1.39.0-10390.apk` — APK Android debug/CI, assinatura v2.
- `jarvis-nova-1.39.0-10390.apk.sha256` — checksum do APK.
- `JARVIS-Nova-1.39.0-fonte.zip` — fonte, testes, documentação e projeto Android.
- `JARVIS-Nova-1.39.0-release.zip` — APK, fonte, notas e checksums.
- `SHA256SUMS-1.39.0.txt` — hashes dos três arquivos.

## O que mudou

- **Camada cognitiva determinística** (`cognicao.js`): intenção, complexidade, pressa, assunto sensível, informalidade, referências, ambiguidade e necessidade de pesquisa/cálculo/ferramenta.
- **Plano interno de cinco etapas**: compreender, contextualizar, decidir, responder e verificar. O plano não é exibido ao usuário.
- **Contexto seletivo**: prioriza mensagens antigas que compartilham termos e referências, sem aumentar indefinidamente o histórico.
- **Verificação e revisão**: detecta fala vazia, abertura genérica, repetição, humor em assunto sensível e alegação de execução sem ferramenta; revisa aberturas e espaços antes de entregar.
- **Personalidade adaptativa**: profundidade, iniciativa e comportamento conversacional persistidos; três níveis de humor e seis eixos existentes preservados.
- **Integração conservadora**: Hermes, Core, SISTEMA, confirmações, memória, voz, avatar e núcleo 3D não foram substituídos. Nenhuma ação sensível ganhou autorização nova.

## Verificações

- `node tests/test_cognicao.js` — 24 verificações.
- `python3 tests/test_v1_39_0.py` — contrato da versão.
- `npm run test:all` — exit 0, incluindo regressões 1.0–1.38.1.
- `aapt`: `com.jarvis.nova`, 1.39.0, versionCode 10390, minSdk 26, targetSdk 34.
- `apksigner`: assinatura v2 verdadeira; chave de CI/debug.

## Limitações

O APK não foi instalado nem executado em aparelho físico. Microfone, wake word, câmera, notificações, acessibilidade, segundo plano e avatar em tela real continuam pendentes. Provedores reais, modelo local, Windows e ESP32/Home Assistant não foram testados nesta rodada. A verificação é heurística: detecta problemas observáveis de forma e segurança, não falsidades factuais. Não houve medição de startup, RAM, CPU ou bateria.
