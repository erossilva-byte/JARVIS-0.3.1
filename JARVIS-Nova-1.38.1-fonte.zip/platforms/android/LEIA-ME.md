# Android

Código nativo (Java) do APK. Os fontes ficam na raiz do repositório (`Jarvis*.java`,
`MainActivity.java`) e os patches de build ficam aqui descritos:

- `patch_manifest.py` — permissões, receivers, serviço em primeiro plano, `usesCleartextTraffic=false`
- `patch_gradle.py` — `minSdkVersion 26`, dependências, assinatura de debug do CI
- `patch_visual.py` — ícone e abertura
- `patch_android_version.py` — `versionCode`/`versionName` de `VERSAO.json`

O workflow de release copia os `.java`, aplica os patches, roda `./gradlew assembleDebug` e publica
o APK com o `.sha256`. O atualizador interno depende da assinatura fixa `ci/debug.keystore`.
