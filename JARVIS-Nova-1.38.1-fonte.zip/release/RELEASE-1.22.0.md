# J.A.R.V.I.S. Nova 1.22.0 — Visão 2.0 e Pessoas

Data: 2026-10-29 · versão 1.22.0 · versionCode 10220 · appId `com.jarvis.nova`

## Novidades

### Visão 2.0
- Balões posicionados por `visao.js` com detecção de colisão, margem e linha-guia: nenhum
  balão cobre outro e nenhum sai da imagem. Com muitos objetos num espaço pequeno, os balões
  são marcados como agrupados em vez de escondidos.
- Tocar num balão **interrompe a fala em curso** (TTS do Android, síntese do navegador e voz
  neural) antes de ler o detalhe; o texto acompanha e o botão "Voltar à análise geral"
  restaura o resumo sem refazer a análise.
- Painel de texto com rolagem e cópia, separado do resumo e do detalhe.
- **Imagem da galeria/arquivo**: reduzida para 1024 px, limite de 16 MB, erros claros.
- **Vídeo MP4/WebM/MOV**: prévia, até 9 quadros extraídos por canvas, análise quadro a quadro
  com timestamp, progresso real, cancelamento e lista clicável. O áudio não é analisado.

### Pessoas
- Perfis locais separados, com nome obrigatório, apelido, relação, descrição, preferências,
  observações e contato opcional.
- Busca por nome/apelido sem acento; nomes parecidos nunca são fundidos — a resposta pergunta
  qual é.
- Exportação JSON, exclusão com confirmação e contexto opcional na IA (sem contato).
- Sem biometria e sem reconhecimento automático de pessoas.

## Correções e integração
- O texto da análise deixou de ser apagado ao reabrir o painel.
- O diagnóstico lista Visão 2.0 e Cadastro de pessoas entre os módulos conferidos do pacote.
- Workflows, `build.gradle`, `package.json`, `package-lock.json` e `VERSAO.json` na mesma
  versão (1.22.0 / 10220).

## Testes executados
- `node tests/test_visao_nova.js` — 8 grupos: colisão, limites, linha-guia, colisão
  impossível, plano de quadros, timestamps, relato e texto.
- `node tests/test_pessoas.js` — 10 grupos: validação, saneamento, edição, ambiguidade,
  busca, descrição, privacidade do contato, persistência, import/export e remoção.
- `python3 tests/test_v1_22_0.py` — contrato de interface, scripts, CSS, diagnóstico,
  versão e ausência de chaves.
- `npm run test:all` — suíte completa (resultado no relatório da conversa).

## Limitações conhecidas
- **APK não gerado nesta revisão**: este ambiente não tem JDK nem Android SDK. O código e os
  testes estão prontos; a compilação deve ser feita por `npm run android:sync` +
  `./gradlew assembleDebug` ou pelo workflow `release-apk.yml` (runner com SDK).
- Sem teste em aparelho físico: câmera, galeria, reprodução de vídeo e fala real não foram
  exercitadas em hardware.
- Análise de vídeo depende de provedor com visão e envia um quadro por vez; sem análise de
  áudio.
- Indicador de fala por notificação/sobreposição fora do app não foi implementado.
