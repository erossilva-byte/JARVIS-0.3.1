# Release 1.21.4 — J.A.R.V.I.S. Nova

**Data:** 2026-10-29 · **versionCode:** 10214 · **appId:** com.jarvis.nova

## Artefato

| Plataforma | Arquivo | Tamanho | SHA-256 |
|---|---|---|---|
| Android | `jarvis-nova-1.21.4-10214.apk` | 67.8 MB | `8c5874a27a82f2cade5c20caa4d01c52858c569c5fdbde5360855f5b3afc557e` |

## Obsidian em Ajustes ▸ Memória

O bloco do cofre saiu do painel avulso e agora fica **dentro da aba Memória**, logo abaixo da
memória pessoal — o lugar onde ele era procurado:

- **ativar/desativar** a memória conectada;
- **escolher a pasta do cofre**: Storage Access Framework no Android (com permissão persistente)
  e diálogo nativo no PC;
- **testar o vínculo**, com leitura/escrita reais e mensagem clara quando não há pasta;
- **enviar notas por tópico** e **trazer do cofre**, sem apagar nada fora de `Memoria/`;
- **organizar por tópicos** e **desconectar** sem perder notas.

A aba consulta o estado real do cofre ao abrir (`cofreStatus`), então não mostra “sem vínculo”
quando a pasta já estava escolhida antes de abrir o app. O painel Memória ganhou o botão
“Abrir Memória nos Ajustes”.

### Separação e recuperação por assunto

Um arquivo por tópico em `Memoria/`: `Gostos.md`, `Preferencias.md`, `Projetos.md`,
`Objetivos.md`, `Estudos.md`, `Dispositivos.md`, `Rotinas.md`, `Conversas importantes.md`,
`Pesquisas.md`, `Contextos.md`. O assunto é deduzido das palavras ditas, a nota existente é
atualizada em vez de duplicada, e `contextoRelevante()` só injeta no prompt o que casa com a
pergunta — sem correspondência, o assistente diz que não há registro em vez de inventar.

## Diagnóstico

- Nova verificação **Erros recentes**: lê o registro do próprio app e conta as falhas das últimas
  24 h, com orientação para abrir o Registro de ações.

## Tela de bloqueio

- Ajuste moderado, sem mudar a identidade nem a segurança: núcleo um pouco menor, grade e brilho
  mais discretos, arcos mais finos, títulos e espaçamentos equilibrados, linhas decorativas
  escondidas em telas estreitas.

## Verificação executada

| Verificação | Resultado |
|---|---|
| `npm run test:all` (inclui `test_v1_21_4.py`, com a memória rodando de verdade) | passa |
| Harness de runtime em DOM real | 168 botões, 0 exceções |
| Fluxo de bloqueio em DOM (abre, PIN errado, espera, Enter bloqueado, PIN certo) | 10/10 |
| APK por dentro: `VERSAO_APP` | `1.21.4` |
| APK por dentro: `id="obs-bloco"` nos assets | presente |
| `aapt2 dump badging` | `com.jarvis.nova`, versionCode `10214`, versionName `1.21.4` |
| Digest publicado no GitHub | `8c5874a27a82f2ca…` (confere com o arquivo local) |

## O que **não** foi validado

- **Aparelho físico**: o seletor SAF do Android, biometria, microfone e câmera não foram exercitados.
  O caminho nativo `cofreStatus`/`cofreEscrever` foi validado por leitura de código e pelos testes
  de invariantes, não por execução em Android.
- **Aparência em tela real**: a tela de bloqueio foi conferida por CSS/DOM, sem navegador aberto.
- **Windows**: pacote PC não regerado nesta versão.

## Instalação

Atualize em **Ajustes ▸ Atualização ▸ Verificar** (o app confere o SHA-256 antes de instalar) ou
instale o APK abaixo por cima — mesma assinatura e mesmo `appId`, os dados locais são preservados.
