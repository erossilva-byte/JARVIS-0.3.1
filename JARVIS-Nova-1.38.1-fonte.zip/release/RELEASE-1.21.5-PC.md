# J.A.R.V.I.S. Nova 1.21.5 — versão PC (Windows)

Expansão do aplicativo para computador, sobre o **mesmo núcleo** do Android. Nada do que
existia foi reescrito: a personalidade, a memória por tópicos, o cofre do Obsidian, os
provedores de IA, o núcleo 3D e o CAD continuam nos arquivos compartilhados da raiz.

## O que o PC ganhou

**Painel ▸ Computador** (barra lateral, só no Electron) com quatro abas:

- **Arquivos** — navegação na pasta do usuário; tipo detectado pela assinatura dos bytes,
  não pela extensão; prévia por formato (tabela para CSV, imagem inline, texto de DOCX,
  planilhas de XLSX, metadados de PDF, metadados de PDF); edição de texto com backup
  `.bak-<data>` e gravação atômica; comparação por bloco; pesquisa dentro dos arquivos;
  conversões reais (`csv↔json`, `md→html`, `html→txt`, `txt→md`); organização por tipo em
  duas etapas (plano → aplicar).
- **CAD** — identificação por conteúdo de `.cad`, DXF, STL, 3MF, STEP, IFC, DWG, FCStd e
  OLE; visualizador em canvas (DXF em linhas/camadas, malha 3D com rotação e zoom);
  criação de peças; alteração que **gera `nome-v2.cad`** e nunca sobrescreve o original;
  exportação com validação por reabertura e lista de perdas.
- **Tarefas** — sequência de passos permitidos, relatório por passo, parada no primeiro
  erro, cancelamento e histórico local.
- **Diagnóstico** — versão, núcleos/memória, disco, provedores com chave (só nomes), cofre
  do Obsidian, ferramentas CAD instaladas e falhas recentes; estados reais, incluindo
  "não verificado".

## Matriz CAD no PC

| Formato | Abre/visualiza | Cria | Edita | Exporta | Limite |
| --- | --- | --- | --- | --- | --- |
| `.cad` CadSimu | sim (malha) | sim | **sim** (nova versão) | sim | — |
| DXF ASCII | sim (linhas/camadas) | sim | não | sim | sem edição por entidade, hachura ou cota |
| STL | sim (malha) | sim | não | sim | sem unidades no arquivo |
| 3MF | não no painel | sim | não | sim | visualize pelo `.cad` de origem |
| STEP | entidades apenas | sim | não | sim | sem kernel B-rep |
| IFC | esquema/elementos | sim | não | sim | sem geometria BIM completa |
| DWG / RVT / RFA / FCStd | **não** | não | não | não | proprietários / exigem FreeCAD |

## Testes executados

| Verificação | Resultado |
| --- | --- |
| `node tests/test_pc_arquivos.js` | 19/19 |
| `node tests/test_pc_cad.js` | 12/12 |
| `python3 tests/test_pc_windows.py` | contrato motores ↔ IPC ↔ painel ↔ build ↔ docs |
| `npm run test:all` | **suíte completa verde** (inclui os três testes acima) |
| Pacote gerado | `win-unpacked` conferido: `pc.js`, `arquivos.js`, `cad_pc.js`, `main.js`, `preload.js` dentro do `app.asar` |

## Instalação (pasta portátil)

1. Baixe `jarvis-nova-1.21.5-pc-portatil.zip` (117 MB, sha256 `d18f42eaee0499bf55ea95ee523654ea1d7108f2ba030d2f59884c490dd50ae1`).
2. Extraia em qualquer pasta e execute `J.A.R.V.I.S. Nova.exe`.
3. O Windows pode avisar que o aplicativo não tem assinatura digital — o pacote é local,
   não assinado; use "Mais informações ▸ Executar assim mesmo" somente se confiar na origem.

Dados do usuário: `%APPDATA%/jarvis-nova` (chaves cifradas pelo sistema e pasta do cofre
autorizada). Atualizar por cima preserva esses arquivos.

## Limitação desta entrega

**O instalador NSIS não foi gerado neste ambiente.** O `electron-builder` exige Wine para
criar o desinstalador do NSIS no Linux, e esta máquina não tem Wine (nem permissão para
instalá-lo). O que foi entregue é a pasta portátil, montada a partir do build real de
`--win dir`.

Para gerar o instalador, use o workflow **Release PC (Windows)**
(`.github/workflows/release-pc.yml`), que roda em `windows-latest`, ou execute em uma
máquina Windows:

```bash
npm ci
npm run dist:win
```

O `.exe` do instalador sairá em `dist/J.A.R.V.I.S. Nova Setup 1.21.5.exe`.

## Não testado (pendências explícitas)

- execução do `.exe` em Windows real (o build foi gerado no Linux; o executável não roda
  aqui) — logo, abertura da janela, clique nos botões e diálogo nativo do Obsidian seguem
  **sem validação em máquina Windows**;
- abertura de DOCX/XLSX/PPTX reais (a extração foi validada pela estrutura ZIP, com
  arquivos sintéticos);
- visualizador CAD na prática (a geometria foi validada por testes, sem screenshot);
- instalador NSIS e assinatura digital;
- captura de tela e voz no Windows.

Nada acima deve ser tratado como aprovado.
