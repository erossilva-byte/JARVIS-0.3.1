# Release 1.21.2 — J.A.R.V.I.S. Nova

**Data:** 2026-10-29 · **versionCode:** 10212 · **appId:** com.jarvis.nova

## Artefatos

| Plataforma | Arquivo | Tamanho | SHA-256 |
|---|---|---|---|
| Android | `jarvis-nova-1.21.2-10212.apk` | 67.8 MB | `c49452c620177c90f1132d79bc6373b8a21a705de92d7aacd5d4883b635ffc44` |
| Windows (EXE portátil) | `jarvis-nova-1.21.2-pc-portatil.exe` | 71.9 MB | `d901759c41156c98d1c665d0c470e93fe0a1df3b3db8b3248f596dcd7235fde8` |
| Windows (pasta portátil) | `jarvis-nova-1.21.2-pc-pasta.zip` | 112.1 MB | `7e52faae914b2544ed6b6b0bebb61c032453c2f7ae2f8e59fc77947c7e444dc0` |

Cada arquivo tem o `.sha256` correspondente ao lado.

## O que esta versão corrige

### 1. Apagar chave de API falhava em silêncio
`app.js` — handler de `#c-apagar-<provedor>`:

```js
// antes: sem catch, a falha virava promessa rejeitada sem dono
$('#c-apagar-' + n).onclick = async () => { await gravarChave(n, ''); ... };

// depois
botao.onclick = async () => {
  try { await gravarChave(n, ''); registrar(...); mostrarChaves(); atualizarChipIA(); }
  catch (e) { const texto = 'Não consegui apagar a chave ' + n + ': ' + ...; registrar('erro', texto); msg('sis', texto); }
};
```

Quando o cofre seguro não existe (navegador comum, ou falha do cofre no Android/desktop), o
clique parecia não fazer nada e nenhum aviso aparecia. Agora a causa é dita ao usuário e
registrada, e o botão ausente não derruba o laço de configuração.

### 2. `npm ci` não instalava
`package-lock.json` estava fora de sincronia com `package.json` (faltavam as dependências do
empacotador Windows, entre elas `electron-builder-squirrel-windows`, `archiver`, `fs-extra`).
O lockfile foi regenerado **sem alterar as versões declaradas**; `npm ci` volta a instalar de
um diretório limpo.

## Verificação executada

| Verificação | Resultado |
|---|---|
| `npm ci` do zero | passa (316 pacotes) |
| `npm run test:all` (suíte completa, inclui `test_v1_21_2.py`) | passa |
| Harness de runtime em DOM real (jsdom): `index.html` + scripts na ordem do app | 12 abas, 167 botões, 0 exceções, 0 promessas rejeitadas |
| Painéis abrem/fecham e o painel de configurações rola | passa |
| Interruptor do cofre persiste (`jv_obs_ativo`) | passa |
| APK por dentro: `assets/public/app.js` | `VERSAO_APP = '1.21.2'` |
| APK: `versionName` / `versionCode` | `1.21.2` / `10212` |
| `app.asar` do PC | `VERSAO_APP = '1.21.2'` |
| Cabeçalho do `.exe` | `MZ` (PE válido) |

## O que **não** foi validado

- **Execução em aparelho Android físico** (microfone, palavra de ativação, TTS, câmera, SAF do cofre).
- **Execução do `.exe`**: esta máquina é Linux; o binário é Windows. Também não há medição de
  latência de voz em hardware real.
- **Instalador NSIS (`Setup.exe`)**: não gerado aqui. O electron-builder precisa de Wine 32 bits
  para gravar versão/ícone, e este container não tem o loader de 32 bits nem root para instalar.
  O `.exe` portátil foi gerado com `-c.win.signAndEditExecutable=false`; por isso ele usa o
  ícone padrão do Electron. Para o instalador com atalhos, rode o workflow
  `.github/workflows/release-pc.yml` em `windows-latest`.

## Como instalar

**Android**
1. Baixe `jarvis-nova-1.21.2-10212.apk`.
2. Autorize "instalar de fontes desconhecidas" para o navegador/gerenciador de arquivos.
3. Instale por cima da versão anterior: mesma assinatura (`ci/debug.keystore`), o atualizador
   in-app reconhece 10212 como mais novo.

**Windows**
1. Baixe `jarvis-nova-1.21.2-pc-portatil.exe` e execute. É portátil: não instala nada e pode ficar em qualquer pasta.
2. O SmartScreen vai avisar na primeira execução porque o binário não é assinado digitalmente.
3. Alternativa: descompacte `jarvis-nova-1.21.2-pc-pasta.zip` e rode `J.A.R.V.I.S. Nova.exe` dentro da pasta.

## Publicação

Publicada no GitHub como **v1.21.2** (marcada como *latest*), no repositório
`erossilva-byte/JARVIS-0.3.1`, com o APK e os checksums anexados. É dessa release que o
atualizador in-app (Ajustes ▸ Atualização ▸ Verificar) passa a baixar.
