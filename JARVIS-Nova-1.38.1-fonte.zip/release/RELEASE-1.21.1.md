# J.A.R.V.I.S. Nova 1.21.1 — release Android + PC

Data: 2026-10-29 · versionCode 10211 · mesma assinatura de CI do APK anterior (atualização in-app funciona).

## O que muda nesta versão
- **Cofre do Obsidian**: o interruptor "Usar o cofre como memória conectada" passou a salvar o estado de verdade e a conferir a pasta escolhida; antes ele não tinha ação nenhuma.
- **Android SAF**: a nota criada no cofre não vira mais `Gostos.md.md` (renomeada para o nome exato logo após a criação).
- **Cancelar o seletor de pasta** deixou de ser reportado como falha de conexão.
- Memória organizada em um arquivo Markdown por tópico em `Memoria/`, recuperação só das notas relevantes e núcleo 3D com quatro anéis, varredura e estados de erro/processamento.

## Arquivos

| Plataforma | Arquivo | Tamanho | SHA-256 |
|---|---|---|---|
| Android (APK) | `jarvis-nova-1.21.1-10211.apk` | 71,211,420 bytes | `4542194e024b46d7be8eba89f380c8329072eafc11cee23250d68ac44d08df6c` |
| Windows (EXE portátil) | `jarvis-nova-1.21.1-pc-portatil.exe` | 75,427,534 bytes | `348f82acf5ed7248466c7573397282d6c179da6a97879e37a827b108d9f4f725` |
| Windows (pasta portátil .zip) | `jarvis-nova-1.21.1-pc-pasta.zip` | 117,549,473 bytes | `3635e75150d8d68eb34b300ad7eba023c4bee0ded8bb22d52eab5d80b3542907` |

Os arquivos `.sha256` ao lado de cada um têm o mesmo valor, no formato usado pelo app.

## Android
1. Baixe o APK e instale (o sistema avisa sobre "fonte desconhecida" por ser build de CI).
2. Ou use **Ajustes ▸ Atualização ▸ Verificar**: o app compara o `versionCode` (10211) com o último release do GitHub.
3. Para vincular o cofre: **Ajustes ▸ Memória ▸ Obsidian ▸ Escolher pasta do cofre**, confirme a permissão, ligue o interruptor e use **Enviar notas por tópico**.

## Windows
1. **Portátil (recomendado)**: execute `jarvis-nova-1.21.1-pc-portatil.exe` — não instala nada, abre direto.
2. **Pasta portátil**: extraia `jarvis-nova-1.21.1-pc-pasta.zip` e rode `J.A.R.V.I.S. Nova.exe` dentro de `win-unpacked`.
3. Vincule o cofre no PC em **Ajustes ▸ Memória ▸ Obsidian** colando o caminho do vault ou usando o diálogo nativo.

## Instalador NSIS — por que não saiu desta máquina
O `electron-builder` chama o `rcedit` **32 bits** para gravar versão/ícone no `.exe`. Este ambiente
não tem loader 32 bits (`/lib/ld-linux.so.2`) nem permissão de root para instalar um; o Wine
disponível é 64 bits e responde `ShellExecuteEx failed`. O `Setup.exe` parcial (~160 kB) foi
apagado de propósito: publicar aquele arquivo daria a impressão de instalador válido.

**Como gerar o instalador (validado no workflow `.github/workflows/release-pc.yml`):**
- Em um runner Windows (`windows-latest`), rode o workflow com a tag `v1.21.1` — ele executa
  `npx electron-builder --win nsis portable --publish never` e só anexa ao release depois de
  conferir que o `Setup.exe` passa de 20 MB e contém a assinatura `Nullsoft`.
- Localmente em Windows: `npm ci && npx electron-builder --win nsis`.
- Em Linux com Wine completo (32 e 64 bits): `npx electron-builder --win nsis` com `WINEPREFIX` próprio.

## Limitações desta entrega
- O **EXE portátil** funciona sem instalação; o instalador com atalho no menu Iniciar depende do passo acima.
- O executável do PC **não é assinado** — o SmartScreen pede confirmação na primeira execução.
- O vínculo SAF não foi testado em aparelho físico (exige toque no seletor e um vault real).
- Sincronização automática entre Android e PC continua manual (enviar/trazer), não contínua.
