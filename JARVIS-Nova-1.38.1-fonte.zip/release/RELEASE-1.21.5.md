# J.A.R.V.I.S. Nova 1.21.5

## Correção principal: o cofre do Obsidian aparecia fora de qualquer aba

O bloco do cofre era um `<section class="grupo">` **sem `data-category`**. A navegação de Ajustes só
mostra e esconde as seções marcadas com uma categoria — por isso o cofre simplesmente não aparecia em
**Ajustes ▸ Memória**, embora os botões existissem no arquivo.

Agora ele é um cartão **dentro da aba Memória**, abaixo da memória pessoal:

- **um único ponto de seleção de pasta** — o campo de texto “Caminho do cofre (PC)” foi removido; a
  pasta vem sempre do seletor do sistema (SAF no Android, diálogo nativo no PC) e o caminho salvo é
  lido do armazenamento;
- **selo de estado** (`conectado`, `falta a pasta`, `desligado`, `sem pasta aqui`) e resumo com
  quantidade de `.md`, permissão de leitura/escrita e existência de `Memoria/`;
- ativar/desativar, testar vínculo, enviar notas por tópico, trazer do cofre, organizar e desconectar
  continuam na mesma seção, sem duplicar controles em outras telas.

## Diagnóstico agrupado por área

- Seis grupos fixos: aplicativo e pacote, inteligência artificial, voz e áudio, memória e dados,
  permissões e sistema, rede e conectividade.
- Cada grupo mostra **quantidade de itens e o pior estado** encontrado; a ordem não muda entre execuções.
- Cada linha continua com estado, descrição, impacto, como resolver, atalho para a aba certa e horário;
  textos longos e o estado interno ficam em **Detalhes técnicos** recolhível.
- Novo botão **Abrir registro de erros** dentro do diagnóstico.

## Interface e animações

- Sistema único de movimento (`--jv-dur-1/2/3`, `--jv-ease`) com três animações compartilhadas por
  seções, painéis, abas, cartões e linhas do diagnóstico — entrada curta em cascata, sem efeitos
  independentes competindo.
- Superfícies unificadas (borda, vidro, sombra) nos cartões de IA, painel, status do celular e
  diagnóstico; selos com cor por severidade e foco visível em todos os controles.
- A animação continua presa ao estado real: `thinking` pulsa o HUD, `listening` e `speaking`
  escalonam as ondas do microfone. Nada se move quando a atividade não existe.
- `prefers-reduced-motion` desliga animações e transições.

## Modelos `.task`

- Bloco “Onde baixar modelos `.task` compatíveis” na aba **IA**, com fontes oficiais: repositório
  `litert-community/Gemma3-1B-IT`, coleção LiteRT Community, guia do MediaPipe LLM Inference e Gemma
  no Kaggle.
- Nomes de arquivo e tamanhos conferidos na API do repositório, limitações de RAM e licença em
  [`MODELOS-IA-LOCAL.md`](../MODELOS-IA-LOCAL.md). O `.task` é binário: nenhum link foi inserido
  dentro do modelo.

## Testes executados

- `npm run test:all` completo, incluindo `tests/test_v1_21_5.py`: **passa**.
- `tests/test_diag_grupos.js` (DOM simulado, funções reais de `app.js`): linhas no grupo certo,
  contagem/pior estado por área, ordem fixa e detalhes recolhíveis — **7/7**.
- `aapt2 dump badging`: `com.jarvis.nova`, versionCode **10215**, versionName **1.21.5**, minSdk 26.
- Conteúdo do APK: `const VERSAO_APP = '1.21.5'`, `obs-pill`, `modelos-card`, `diag-abrir-log` e as
  regras novas de CSS presentes nos assets empacotados; nenhuma referência a `obs-caminho`.

## Limitações declaradas

- Sem aparelho físico: o seletor SAF do Android, biometria, microfone e câmera não foram exercitados
  nesta versão.
- A aparência foi conferida por CSS/DOM e pelo pacote gerado; não houve captura em navegador.
- O pacote Windows não foi regerado nesta revisão.

## Instalação

`jarvis-nova-1.21.5-10215.apk` · 71,2 MB · assinado com a chave de `ci/debug.keystore`, a mesma dos
releases anteriores — instala por cima da 1.21.4 sem desinstalar. Atualização pelo próprio app:
**Ajustes ▸ Atualização ▸ Verificar** depois que este release estiver publicado no GitHub.
