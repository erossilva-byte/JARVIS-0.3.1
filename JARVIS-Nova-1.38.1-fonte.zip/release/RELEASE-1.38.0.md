# J.A.R.V.I.S. Nova 1.38.0

**Avatar 3D procedural, plano persistente e executores do Core.**

## Arquivos

- `jarvis-nova-1.38.0-10380.apk` — APK Android (debug/CI, assinatura v2), 81.196.059 bytes.
- `jarvis-nova-1.38.0-10380.apk.sha256` — checksum do APK.
- `JARVIS-Nova-1.38.0-fonte.zip` — código-fonte, testes, documentação e projeto Android (sem `node_modules`, builds e APKs antigos).
- `JARVIS-Nova-1.38.0-release.zip` — APK + checksum + relatórios de IA/repertório e LEIA-ME.

SHA-256 do APK: `3fbe237a672eca13f308a266c86e0503d13ddcfa54fdd4e75308bb0b8cae27ba`.

## O que mudou

- Avatar holográfico 3D local com boca reagindo à **amplitude** da voz; fallback Canvas 2D; sem modelo facial baixado e sem visemas fonéticos.
- “Planeje …” agora vira tarefa persistente do Sistema, com checkpoint, pausa e retomada sem repetir etapa. A confirmação da ação real não é duplicada.
- Core com executores de leitura para voz, automação, atualização e planejamento.
- Auditorias de IA e do repertório incluídas.

## Limitações declaradas

O APK não foi instalado nem executado em aparelho físico. Microfone, wake word, notificações, acessibilidade, segundo plano e avatar em tela real continuam pendentes de validação no Poco X7. Chaves de IA e modelo `.task` reais, Windows, ESP32 e Home Assistant não foram testados. O APK é debug/CI, não uma build de produção.
