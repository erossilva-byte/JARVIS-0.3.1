# Release 1.21.3 — J.A.R.V.I.S. Nova

**Data:** 2026-10-29 · **versionCode:** 10213 · **appId:** com.jarvis.nova

## Artefato

| Plataforma | Arquivo | Tamanho | SHA-256 |
|---|---|---|---|
| Android | `jarvis-nova-1.21.3-10213.apk` | 67.9 MB | `66709e06b2a14c3764c0f38d688020ebfe8636f22b34bd62b11749ea90b80e16` |

O `.sha256` está anexado ao lado — é o digest que o atualizador in-app confere após o download.

## Tela de bloqueio

- Núcleo holográfico com **quatro arcos SVG** girando em sentidos alternados, varredura
  luminosa, grade e brilho de fundo.
- **Relógio e data em tempo real**, indicador de estado do sistema e **pontos de PIN** que
  acompanham a digitação.
- **Tremor curto** no PIN errado e saída animada de 260 ms ao desbloquear — sem atrasar o uso.
- Continua **opcional** (Ajustes ▸ Segurança), não substitui a tela de bloqueio do Android e
  mantém PIN com hash SHA-256, biometria/credencial pelo plugin `JarvisSeguranca` e código de
  recuperação. Respeita `prefers-reduced-motion`.

### Correção de segurança encontrada no teste

O atraso progressivo após PIN errado só desabilitava o botão — a tecla **Enter** continuava
chamando a validação e furava o limite de tentativas. A espera agora é gravada e conferida
dentro de `tentarDesbloquear()`, então vale para qualquer caminho de entrada.

## Diagnóstico real

- Sete estados: **Operacional, Aviso, Falha, Não configurado, Desativado, Não aplicável e Não
  verificado**. Recurso opcional desligado não aparece como defeito; o que não pôde ser
  conferido não aparece como sucesso.
- Cada item traz **impacto**, **como resolver**, **atalho para o ajuste** e **horário**; o topo
  resume a execução (falhas, avisos, total, duração).
- Verificações novas: módulos carregados do pacote, identidade do app em execução, persistência
  (grava, lê e apaga), configurações realmente salvas, cofre do Obsidian, rotinas e serviço de
  escuta em segundo plano.
- Integridade/assinatura do `.apk` continuam na compilação, e a tela diz isso — não afirma que o
  pacote está íntegro só porque abriu.

## Verificação executada

| Verificação | Resultado |
|---|---|
| `npm run test:all` (inclui `test_v1_21_3.py`) | passa |
| Harness de runtime em DOM real (jsdom) | 12 abas, 167 botões, 0 exceções |
| Fluxo de bloqueio em DOM: abre, relógio/data, pontos, PIN errado, espera, Enter bloqueado, PIN certo | passa |
| APK por dentro: `assets/public/app.js` | `VERSAO_APP = '1.21.3'` |
| `aapt2 dump badging` | `com.jarvis.nova`, versionCode `10213`, versionName `1.21.3`, minSdk 26 |
| Digest do asset publicado no GitHub | deve ser igual a `66709e06b2a14c37…` |

## O que **não** foi validado

- **Aparelho Android físico**: biometria real, câmera, microfone, palavra de ativação e SAF do cofre.
- **Aparência em telas reais** (aqui só há DOM e CSS; nenhum navegador foi aberto).
- **Windows**: o pacote PC não foi regerado nesta versão; o foco desta release é o APK.

## Instalação

1. Em **Ajustes ▸ Atualização ▸ Verificar**, o app baixa esta versão, confere o SHA-256 e entrega
   ao instalador do Android.
2. Ou baixe o APK abaixo e instale por cima: mesma assinatura (`ci/debug.keystore`) e mesmo
   `appId`, então a atualização preserva os dados locais.
